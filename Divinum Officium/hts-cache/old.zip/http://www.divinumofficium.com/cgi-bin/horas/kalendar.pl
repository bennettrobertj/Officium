<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML><HEAD>
  <META NAME="Resource-type" CONTENT="Document">
  <META NAME="description" CONTENT="Divine Office">
  <META NAME="keywords" CONTENT="Divine Office, Breviarium, Liturgy, Traditional, Zsolozsma">
  <META NAME="Copyright" CONTENT="Like GNU">
  <TITLE>Kalendarium: November 2018</TITLE>

<SCRIPT TYPE='text/JavaScript' LANGUAGE='JavaScript1.2'>

function callbrevi(date) {   
  if (!date) date = '';
  var officium = "";
  if (!officium || !officium.match('.pl')) officium = "officium.pl";    
  document.forms[0].date.value = date;
  document.forms[0].action = officium;
  document.forms[0].target = "_self"
  document.forms[0].submit();
}

function setkm(km) {
  document.forms[0].kmonth.value = km;
  document.forms[0].submit();
}  

function setky(ky) { 
  document.forms[0].kyear.value = ky;
  document.forms[0].submit();
} 

function readings() { 
  document.forms[0].readings.value = 1; 
  document.forms[0].submit();
}
</SCRIPT>
</HEAD><BODY VLINK=blue LINK=blue BACKGROUND="http://divinumofficium.com/www/horas/horasbg.jpg" > 
<FORM ACTION="kalendar.pl" METHOD=post TARGET=_self>
<INPUT TYPE=HIDDEN NAME=setup VALUE="general;;;$expand='all';;$version='Rubrics 1960';;$lang2='English';;$accented='plain';;;generalc;;;$expand='all';;$version1='Divino Afflatu';;$version2='Rubrics 1960';;$lang2='English';;$accented='plain';;;generalccheck;;;ooooo;;;generalcheck;;;oooo;;;parameters;;;$priest='0';;$building='0';;$lang1='Latin';;$psalmvar='0';;$whitebground='1';;$blackfont='black';;$smallblack='-1 black';;$redfont=' italic red';;$initiale='+2 bold italic red';;$largefont='+1 bold italic red';;$smallfont='1 red';;$titlefont='+1 red';;$screenheight='1024';;$textwidth='100';;;parameterscheck;;;bbtbbtcccccccnn;;;">
<INPUT TYPE=HIDDEN NAME=date1 VALUE="11-22-2018">
<INPUT TYPE=HIDDEN NAME=kmonth VALUE=11>
<INPUT TYPE=HIDDEN NAME=kyear VALUE=2018>
<INPUT TYPE=HIDDEN NAME=date VALUE="11-22-2018">
<INPUT TYPE=HIDDEN NAME=command VALUE="">
<INPUT TYPE=HIDDEN NAME=officium VALUE="">
<INPUT TYPE=HIDDEN NAME=browsertime VALUE="">
<INPUT TYPE=HIDDEN NAME=readings VALUE="0">

<P ALIGN=CENTER><FONT SIZE=1>
<A HREF=# onclick="setky(2009)">2009</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2010)">2010</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2011)">2011</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2012)">2012</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2013)">2013</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2014)">2014</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2015)">2015</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2016)">2016</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2017)">2017</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2018)">2018</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="callbrevi();"><FONT COLOR=maroon>Hodie</FONT></A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2019)">2019</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2020)">2020</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2021)">2021</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2022)">2022</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2023)">2023</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2024)">2024</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2025)">2025</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2026)">2026</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2027)">2027</A>&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setky(2028)">2028</A>&nbsp;&nbsp;&nbsp;
<BR><BR></FONT>
Rubrics 1960 : <FONT COLOR=MAROON SIZE=+1><B><I>Kalendarium: November 2018</I></B></FONT>
<BR><FONT SIZE=1><BR>
<A HREF=# onclick="setkm(1)">Jan</A>
&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setkm(2)">Feb</A>
&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setkm(3)">Mar</A>
&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setkm(4)">Apr</A>
&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setkm(5)">Maj</A>
&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setkm(6)">Jun</A>
&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setkm(7)">Jul</A>
&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setkm(8)">Aug</A>
&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setkm(9)">Sep</A>
&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setkm(10)">Oct</A>
&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setkm(11)">Nov</A>
&nbsp;&nbsp;&nbsp;
<A HREF=# onclick="setkm(12)">Dec</A>
<P ALIGN=CENTER>
<TABLE BORDER=1 WIDTH=90% CELLPADDING=3>
<TR><TH>Dies</TH><TH>de Tempore</TH><TH>Sanctorum</TH><TH>d.h.</TH><TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-01-2018');"><FONT SIZE=1>01</FONT></A></TD>
<TD><I><FONT COLOR="black">Scriptura: Feria Quinta infra Hebd XXIII post Octavam Pentecostes V. Octobris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="red"><I>Omnium Sanctorum </I></FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; I. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Thu</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-02-2018');"><FONT SIZE=1>02</FONT></A></TD>
<TD><I><FONT COLOR="black">Tempora: Feria Sexta infra Hebd XXIII post Octavam Pentecostes V. Octobris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="red"><I>In Commemoratione Omnium Fidelium Defunctorum </I></FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; I. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Fri</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-03-2018');"><FONT SIZE=1>03</FONT></A></TD>
<TD><B><FONT COLOR="blue">Sanctae Mariae Sabbato </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><I><FONT COLOR="black">Tempora: Sabbato infra Hebdomadam XXIII post Octavam Pentecostes V. Octobris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Sat</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-04-2018');"><FONT SIZE=1>04</FONT></A></TD>
<TD><B><FONT COLOR="red"><I>Dominica IV Post Epiphaniam I. Novembris </I></FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; II. classis</FONT></TD>
<TD><P ALIGN=CENTER>_</P></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Sun</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-05-2018');"><FONT SIZE=1>05</FONT></A></TD>
<TD><B><FONT COLOR="black">Feria Secunda infra Hebd IV post Epiphaniam I. Novembris </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><P ALIGN=CENTER>_</P></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Mon</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-06-2018');"><FONT SIZE=1>06</FONT></A></TD>
<TD><B><FONT COLOR="black">Feria Tertia infra Hebd IV post Epiphaniam I. Novembris </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><P ALIGN=CENTER>_</P></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Tue</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-07-2018');"><FONT SIZE=1>07</FONT></A></TD>
<TD><B><FONT COLOR="black">Feria IV infra Hebd IV post Epiphaniam I. Novembris </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><P ALIGN=CENTER>_</P></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Wed</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-08-2018');"><FONT SIZE=1>08</FONT></A></TD>
<TD><B><FONT COLOR="black">Feria V infra Hebd IV post Epiphaniam I. Novembris </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><FONT SIZE=-1 COLOR="black">Commemoratio ad Laudes tantum: Ss. Quatuor Coronatorum Martyrum</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Thu</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-09-2018');"><FONT SIZE=1>09</FONT></A></TD>
<TD><I><FONT COLOR="black">Tempora: Feria VI infra Hebd IV post Epiphaniam I. Novembris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="red"><I>In Dedicatione Basilicæ Ss. Salvatoris </I></FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; II. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Fri</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-10-2018');"><FONT SIZE=1>10</FONT></A></TD>
<TD><I><FONT COLOR="black">Scriptura: Sabbato infra Hebd IV post Epiphaniam I. Novembris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="black">S. Andreæ Avellini Confessoris </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; III. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Sat</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-11-2018');"><FONT SIZE=1>11</FONT></A></TD>
<TD><B><FONT COLOR="red"><I>Dominica V Post Epiphaniam III. Novembris </I></FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; II. classis</FONT></TD>
<TD><P ALIGN=CENTER>_</P></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Sun</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-12-2018');"><FONT SIZE=1>12</FONT></A></TD>
<TD><I><FONT COLOR="black">Scriptura: Feria II infra Hebd V post Epiphaniam III. Novembris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="black">S. Martini Papæ et Martyris </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; III. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Mon</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-13-2018');"><FONT SIZE=1>13</FONT></A></TD>
<TD><I><FONT COLOR="black">Scriptura: Feria III infra Hebd V post Epiphaniam III. Novembris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="black">S. Didaci Confessoris </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; III. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Tue</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-14-2018');"><FONT SIZE=1>14</FONT></A></TD>
<TD><I><FONT COLOR="black">Scriptura: Feria IV infra Hebd V post Epiphaniam III. Novembris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="black">S. Josaphat Episcopi et Martyris </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; III. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Wed</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-15-2018');"><FONT SIZE=1>15</FONT></A></TD>
<TD><I><FONT COLOR="black">Scriptura: Feria V infra Hebd V post Epiphaniam III. Novembris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="black">S. Alberti Magni Episcopi Confessoris et Ecclesiæ Doctoris </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; III. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Thu</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-16-2018');"><FONT SIZE=1>16</FONT></A></TD>
<TD><I><FONT COLOR="black">Scriptura: Feria VI infra Hebd V post Epiphaniam III. Novembris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="black">S. Gertrudis Virginis </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; III. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Fri</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-17-2018');"><FONT SIZE=1>17</FONT></A></TD>
<TD><I><FONT COLOR="black">Scriptura: Sabbato infra Hebd V post Epiphaniam III. Novembris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="black">S. Gregorii Thaumaturgi Episcopi et Confessoris </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; III. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Sat</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-18-2018');"><FONT SIZE=1>18</FONT></A></TD>
<TD><B><FONT COLOR="red"><I>Dominica VI Post Epiphaniam IV. Novembris </I></FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; II. classis</FONT></TD>
<TD><P ALIGN=CENTER>_</P></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Sun</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-19-2018');"><FONT SIZE=1>19</FONT></A></TD>
<TD><I><FONT COLOR="black">Scriptura: Feria II infra Hebd VI post Epiphaniam IV. Novembris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="black">S. Elisabeth Viduæ </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; III. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Mon</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-20-2018');"><FONT SIZE=1>20</FONT></A></TD>
<TD><I><FONT COLOR="black">Scriptura: Feria III infra Hebd VI post Epiphaniam IV. Novembris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="black">S. Felicis de Valois Confessoris </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; III. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Tue</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-21-2018');"><FONT SIZE=1>21</FONT></A></TD>
<TD><I><FONT COLOR="black">Scriptura: Feria IV infra Hebd VI post Epiphaniam IV. Novembris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="blue">In Præsentatione Beatæ Mariæ Virginis </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; III. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Wed</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-22-2018');"><FONT SIZE=1>22</FONT></A></TD>
<TD><I><FONT COLOR="black">Scriptura: Feria V infra Hebd VI post Epiphaniam IV. Novembris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="black">S. Cæciliæ Virginis et Martyris </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; III. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Thu</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-23-2018');"><FONT SIZE=1>23</FONT></A></TD>
<TD><I><FONT COLOR="black">Scriptura: Feria VI infra Hebd VI post Epiphaniam IV. Novembris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="black">S. Clementis I Papæ et Martyris </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; III. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Fri</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-24-2018');"><FONT SIZE=1>24</FONT></A></TD>
<TD><I><FONT COLOR="black">Scriptura: Sabbato infra Hebd VI post Epiphaniam IV. Novembris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="black">S. Joannis a Cruce Confessoris et Ecclesiæ Doctoris </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; III. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Sat</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-25-2018');"><FONT SIZE=1>25</FONT></A></TD>
<TD><B><FONT COLOR="red"><I>Dominica XXIV et Ultima Post Pentecosten V. Novembris </I></FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; II. classis</FONT></TD>
<TD><P ALIGN=CENTER>_</P></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Sun</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-26-2018');"><FONT SIZE=1>26</FONT></A></TD>
<TD><I><FONT COLOR="black">Scriptura: Feria Secunda infra Hebd XXIV post Octavam Pentecostes V. Novembris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="black">S. Silvestri Abbatis </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; III. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Mon</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-27-2018');"><FONT SIZE=1>27</FONT></A></TD>
<TD><B><FONT COLOR="black">Feria Tertia infra Hebd XXIV post Octavam Pentecostes V. Novembris </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><P ALIGN=CENTER>_</P></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Tue</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-28-2018');"><FONT SIZE=1>28</FONT></A></TD>
<TD><B><FONT COLOR="black">Feria Quarta infra Hebd XXIV post Octavam Pentecostes V. Novembris </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><P ALIGN=CENTER>_</P></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Wed</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-29-2018');"><FONT SIZE=1>29</FONT></A></TD>
<TD><B><FONT COLOR="black">Feria Quinta infra Hebd XXIV post Octavam Pentecostes V. Novembris </FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><FONT SIZE=-1 COLOR="black">Commemoratio ad Laudes tantum: S. Saturnini Martyris</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Thu</FONT></TD>
</TR>
<TR><TD ALIGN=CENTER><A HREF=# onclick="callbrevi('11-30-2018');"><FONT SIZE=1>30</FONT></A></TD>
<TD><I><FONT COLOR="black">Tempora: Feria Sexta infra Hebd XXIV post Octavam Pentecostes V. Novembris </FONT></I><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; IV. classis</FONT></TD>
<TD><B><FONT COLOR="red"><I>S. Andreæ Apostoli </I></FONT></B><FONT SIZE=1 COLOR="maroon">&nbsp;&nbsp; II. classis</FONT></TD>
<TD ALIGN=CENTER><FONT SIZE=1>Fri</FONT></TD>
</TR>
</TABLE><BR>
<SELECT NAME=version SIZE=7 onchange="document.forms[0].submit();">
<OPTION  VALUE="pre Trident Monastic">pre Trident Monastic
<OPTION  VALUE="Trident 1570">Trident 1570
<OPTION  VALUE="Trident 1910">Trident 1910
<OPTION  VALUE="Divino Afflatu">Divino Afflatu
<OPTION  VALUE="Reduced 1955">Reduced 1955
<OPTION SELECTED VALUE="Rubrics 1960">Rubrics 1960
<OPTION  VALUE="1960 Newcalendar">1960 Newcalendar
</SELECT>
&nbsp;&nbsp;&nbsp;
<SELECT NAME=testmode SIZE=3 onclick="document.forms[0].submit();">
<OPTION SELECTED VALUE='regular'>regular
<OPTION  VALUE='Season'>Season
<OPTION  VALUE='Saint'>Saint
</SELECT>
</FORM>
</BODY></HTML>
