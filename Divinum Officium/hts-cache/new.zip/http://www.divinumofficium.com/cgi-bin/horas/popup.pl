<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<HTML><HEAD>
  <META NAME="Resource-type" CONTENT="Document">
  <META NAME="description" CONTENT="Divine Office">
  <META NAME="keywords" CONTENT="Divine Office, Breviarium, Liturgy, Traditional, Zsolozsma">
  <META NAME="Copyright" CONTENT="Like GNU">
  <TITLE> </TITLE>

<SCRIPT TYPE='text/JavaScript' LANGUAGE='JavaScript1.2'>

function setsize() {
  window.resizeTo(400, 768);
}

</SCRIPT>
</HEAD><BODY VLINK=blue LINK=blue BACKGROUND="http://divinumofficium.com/www/horas/horasbg.jpg" 
  onload="setsize()"> 
<FORM>
<H3 ALIGN=CENTER><FONT COLOR=MAROON><B><I></I></B></FONT></H3>
<P ALIGN=CENTER><BR>
<TABLE BORDER=0 WIDTH=90% ALIGN=CENTER CELLPADDING=8 CELLSPACING=1 BGCOLOR='maroon'>
<TR>
<TD BGCOLOR="white" WIDTH=50% VALIGN=TOP><FONT COLOR="black"><BR>
</FONT></TD>
<TD BGCOLOR="white" VALIGN=TOP><FONT COLOR="black"><BR>
</FONT></TD></TR>
</TABLE><BR>
<A HREF=# onclick="window.close()">Close</A></FORM></BODY></HTML>